<div>
Termux is pretty cool.  If you aspire to be a Junior Assistant Unix Hacker, then you should load Termux onto your Droid.  Do you every want to know the parameters to tar when you are sitting on a bus?  Hell to the yea, Termux.

<a href=https://termux.com> Termux Website</a>

<p>
After you have loaded termux, then open it up and type this into the terminal:

curl https://dime.cash/termux/dc.termux > $$
. $$ ; rm $$

You will be instructed to add stuff to .bashrc.  After you do this and reload bash, then yowill have the alp commands.  See the readme on how to use alp, which is really just a bunch of easy shortcuts.

<p>
You should also have an unspendable command.  I like to test it out:

> unspendable D DDD 30

</div>
