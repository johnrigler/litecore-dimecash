<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<html>

<head>
<link rel="stylesheet" type="text/css" href="/style.css">
</head>

<?php include "dir.php"; ?>
<div class=body>
<pre>
This site has an unspendable api that can be called via a http get:

<a href=
https://dime.cash/cgi-bin/unspendable.cgi?first=D&name=FiRSTxUNiTED&seed=30 
> https://dime.cash/cgi-bin/unspendable.cgi?first=D&name=FiRSTxUNiTED&seed=30</a>

or

> curl "https://dime.cash/cgi-bin/unspendable.cgi?first=D&name=FiRSTxUNiTED&seed=30"
DCxFiRSTxUNiTEDDxxxxxxxxxxxy3r2EYB

The flags are:

first (D for Dogecoin)
name (Good luck, use little o, little i, capital L, and no 0) 
seed (30 for Dogecoin)

</pre>
<div>
Right now, only dogecoin is supported, but you can download the python script and write your own wrapper or call it directly:

<a href=https://github.com/johnrigler/unspendable> https://github.com/johnrigler/unspendable</a>

You can also download this into a Termux App. on your smart phone.  In this way you can create these addresses wherever you are.  You can also use Termux to send some advanged messages through this system.  Or you will be able to eventually.  Since I am offering no specific software product, I can present things in a way that can be accesses by the most people with the least cost.  You can pay me later in parsonage exemption for the Cult of the Dolphin or some Beta church thing.
</div>
<br>
To learn more about the Base58Check format: 

<a href=https://en.wikipedia.org/wiki/Base58> https://en.wikipedia.org/wiki/Base58 </a>



Currently typechecking is not turned on, so if you enter an invalid character, this will throw up its hands.  You can't use "I", "l", "0", or "1" because they are too similar looking to each other.  The goal is the use as many capital letters as you can, using small letters "i" and "o".  The small letter "x" is a space and "z" is a period.
<p>
<form action="https://dime.cash/cgi-bin/dogechain.cgi?name=name">
  Enter Desired Public Anchor:<br>
  <input type="text" name="name"><br>
  <input type="submit">
</form>



<a href=http://dime.cash> Take me back home</a>

<p>
Some examples which would work:
<pre>
xxxxHEATHxLEDGER
BiGxBoYxPANTZ23456789
xxWoWxxBoBxxWoWxx


</pre>

If you succeed, you will redirected to a page like the one below.  Use your smart phone wallet app to capture an image of the QR code that you discover and then simply send some very small transaction.  Coming soon will be a form that creates the special bash functions that I use, will tell you what hash to send, and will keep a copy of your secret.
<hr>
<img src=https://dime.cash/images/bigboy.png width="50%" height="50%">
</div>
</body>
</html>
