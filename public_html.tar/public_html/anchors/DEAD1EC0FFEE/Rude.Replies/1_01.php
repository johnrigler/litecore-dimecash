<?php $str=`cat Begin-14878.1`; echo $str; ?>
