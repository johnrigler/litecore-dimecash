<div>

<pre>
dime@dime.cash [~/www/Rude.Replies]# a.fS Begin
Begin-6756438754.452
dime@dime.cash [~/www/Rude.Replies]# ls -l
total 20
drwxrwxr-x  2 dime dime   4096 Jun 23 11:19 ./
drwxr-x--- 16 dime nobody 4096 Jun 23 11:15 ../
-rw-rw-r--  1 dime dime     46 Jun 23 11:17 1_01.php
-rw-rw-r--  1 dime dime      0 Jun 21 14:03 Begin-14878.1
-rw-rw-r--  1 dime dime    152 Jun 23 11:19 Begin-6756438754.452
lrwxrwxrwx  1 dime dime     10 Jun 23 11:16 dir.php -> ../dir.php
-rw-r-----  1 dime dime    274 Jun 23 11:16 index.php
dime@dime.cash [~/www/Rude.Replies]# a.fs Begin
Begin-14878.1
dime@dime.cash [~/www/Rude.Replies]# ls -l
total 24
drwxrwxr-x  2 dime dime   4096 Jun 23 11:19 ./
drwxr-x--- 16 dime nobody 4096 Jun 23 11:15 ../
-rw-rw-r--  1 dime dime     46 Jun 23 11:17 1_01.php
-rw-rw-r--  1 dime dime    152 Jun 23 11:19 Begin-14878.1
-rw-rw-r--  1 dime dime    152 Jun 23 11:19 Begin-6756438754.452
lrwxrwxrwx  1 dime dime     10 Jun 23 11:16 dir.php -> ../dir.php
-rw-r-----  1 dime dime    274 Jun 23 11:16 index.php
dime@dime.cash [~/www/Rude.Replies]#
</pre>
<a href=http://deadlycoffee.com/hello-worpress-my-old-friend-ive-come-to-type-on-you-again-because-it-seemed-to-be-the-thing-that-would-really-make-my-soul-sing-etc-etc-etc-bridge-repeat/> DEAD1EC0FFEE </a>




</div>
