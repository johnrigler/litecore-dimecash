<h1>ps4 </h1>
<pre>

<?php 



#print_r($_SERVER);

$info = explode(" ",$_SERVER[HTTP_USER_AGENT]);

if ($info[1] == '(PlayStation')
    echo "PSPSPSPSPS";
else
    echo "Not Hotdog";


#echo "$_SERVER[HTTP_USER_AGENT]";
#`echo "$_SERVER[HTTP_USER_AGENT]" >> agents.txt`;
$name="Name_A4";

$eval = "$name() { :; } ; declare -f  a2 ; declare -f a2 | sum`"; 

$eval = "date ; xx() { :; } ; declare -f xx ; declare -f xx | sum";
echo `$eval`;
echo `cat fun.times-38075.1`;

 ?>

</pre>
