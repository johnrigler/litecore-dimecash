<div>Hello Dolphin fans and Cult hopefools.  This is the directory stub for the public directory on dimecash.</div> 
<hr>

<div>We here at the church are excited to greet our first visitors, who happen to be bots...

<pre>
<?

$Result=`ls -l X* | cut -c 43-`; 

echo $Result;

?>
</pre>
