<pre>

<? echo `cat heli*`; ?>

</pre>
