<?
echo `curl -s "https://dime.cash/cgi-bin/unspendable.cgi?first=D&name=FiRSTxUNiTED&seed=30"`;
?>
