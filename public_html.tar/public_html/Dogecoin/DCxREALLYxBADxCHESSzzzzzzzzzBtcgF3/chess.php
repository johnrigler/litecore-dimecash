<div>
This anchor references an Android Game that uses a strange chess board to try and create fairness between players.  The board can be represented as either a set of eight sequencial transactions, or as a hash like the one below.  
<p>
A normal chess game could make use of these same systems to be carried out across the Dogecoin blockchain.  Special codes such as 888 for error, 111 for check, and 222 for checkmate could be used. 

<hr>
<pre>
<? echo `cat Really*` ?>
</pre>
